<?php
    session_name(SESSION_NAME);
    session_start();