<?php
	
	/*----------  Datos del servidor  ----------*/
	const SERVER="localhost";
	const DB="sto-main";
	const USER="root";
	const PASS="";


	const SGBD="mysql:host=".SERVER.";dbname=".DB;


	/*----------  Datos de la encriptacion (No modificar) ----------*/
	const METHOD="AES-256-CBC";
	const SECRET_KEY='$STO@2021';
	const SECRET_IV='102791';